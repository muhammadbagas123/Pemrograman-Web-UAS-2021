Aplikasi sewa menggunakan codeigniter dengan fitur sebagai berikut
1. Dapat melakukan pemesanan 
2. Dapat mengelola data 
3. Halaman Frontpage
4. Halaman Admin
