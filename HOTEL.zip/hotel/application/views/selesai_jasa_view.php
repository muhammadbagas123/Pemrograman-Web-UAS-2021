<?php $this->load->view('header'); ?>
<style>
@media print {
body * {
  visibility: hidden;
}
#print, #print * {
  visibility: visible;
}
#print {
  position: absolute;
  width: 100%;
  left: 0;
  top: 0;
}
.noprint{
  display: none;
}
}
</style>
<div class="head-bread">
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>">Home</a></li>
            <li class="active">Selesai</li>
        </ol>
    </div>
</div>


<?php $this->load->view('footer'); ?>
