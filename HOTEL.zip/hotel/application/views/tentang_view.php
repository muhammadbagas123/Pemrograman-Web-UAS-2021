<?php $this->load->view('header'); ?>
<div class="head-bread">
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>">Home</a></li>
            <li class="active">Jasa</li>
        </ol>
    </div>
</div>
    <div class="container">
            <div class="col-md-6">
              <p align="justify">WEBSITE ini dibuat untuk melaksanakan Ujian Akhir Semester IF430 2021.</p>
              <p align="justify">Nama Anggota Kelompok</p>
              <p align="justify">Muhammad Bagas Pangestu - 00000032962</p>
              <p align="justify">Araffi Luthfian Harits 00000033232</p>
              <p align="justify">Erlangga Teruna Prawirakusuma 00000033430</p>
              <p align="justify">Muhammad Zidane Fattah Haq 00000038818</p>
              <div class="item">
              <img src="<?php echo base_url('theme/user/images/hotel1.jpg');?>" alt="...">
                </div>
            </div>
          </div>
            </div>
            
            <div class="clearfix"></div>
    </div>
<?php $this->load->view('footer'); ?>
