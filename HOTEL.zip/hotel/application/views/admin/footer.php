      </section>
      </div>
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>UAS</b> IF430
        </div>
        <strong> &copy; 2021 HOTEL IF430</a>.</strong> HOTELIN
      </footer>
    </div>
  </body>
</html>
