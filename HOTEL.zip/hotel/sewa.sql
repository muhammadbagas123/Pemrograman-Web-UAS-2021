-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Jun 2021 pada 17.38
-- Versi server: 10.4.19-MariaDB
-- Versi PHP: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sewa`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_jasa`
--

CREATE TABLE `jenis_jasa` (
  `jenis_jasa_id` int(11) NOT NULL,
  `nama_jasa` varchar(45) DEFAULT NULL,
  `harga_jasa` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `kategori_id` int(11) NOT NULL,
  `nama_kategori` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`kategori_id`, `nama_kategori`) VALUES
(4, 'Hotel Class A'),
(5, 'Hotel Class B'),
(6, 'Hotel Class C');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `produk_id` int(11) NOT NULL,
  `kategori_id` varchar(45) DEFAULT NULL,
  `nama_produk` varchar(255) DEFAULT NULL,
  `harga` varchar(45) DEFAULT NULL,
  `stok` varchar(45) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `gambar` text DEFAULT NULL,
  `created_on` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`produk_id`, `kategori_id`, `nama_produk`, `harga`, `stok`, `deskripsi`, `gambar`, `created_on`) VALUES
(5, '4', 'Hotel Tangerang ABIS', '500000', '1', 'Hotel Tangerang ABIS berada di daerah kabupaten Tangerang.', 'aac233d82921211db79ef31bee373fa0.jpg', '2021-06-10 01:59:01'),
(6, '5', 'Hotel AA.JUN', '300000', '4', 'Hotel AA.JUN terletak di pinggir jalan kota Tangerang.', '5591cde9a198afdf80ddcebb177d29c7.jpg', '2021-06-10 02:02:40'),
(7, '6', 'Hotel IBLIS SEREM', '200000', '6', 'Hotel IBLIS SEREM terletak di mana mana', '4936005c7245862c651ea0f3b7d71c7d.jpg', '2021-06-10 02:05:40'),
(8, '6', 'Hotel DONG', '200000', '3', 'Hotel DONG terletak di samping bengkel motor.', '6f7aee22550470c336fea067b08e6523.jpg', '2021-06-10 02:07:51'),
(9, '4', 'Hotel Tangerang ABIS', '500000', '3', 'BOOKING DOONG', '796d055a2d9a6499d0b8b8df5708372f.jpg', '2021-06-10 02:14:08'),
(10, '4', 'Hotel Tangerang ABIS', '1000000', '1', 'VIP', 'b9e3edce546b4e92256d1f0b704bc1d1.jpg', '2021-06-10 02:16:17'),
(11, '5', 'Hotel AA.JUN', '300000', '4', 'YUK BOOKING SEKARANG', 'c75c2aed6db8c874d521af545480e661.jpg', '2021-06-10 02:18:00'),
(12, '5', 'Hotel AA.JUN', '300000', '3', 'BOOKING DONG', '1d5ee56e92d1f261c17e68e5f4806b5c.jpg', '2021-06-10 02:20:40');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `transaksi_id` int(11) NOT NULL,
  `user_id` varchar(45) DEFAULT NULL,
  `produk_id` varchar(45) DEFAULT NULL,
  `dari` date DEFAULT NULL,
  `sampai` date DEFAULT NULL,
  `jumlah` varbinary(45) DEFAULT NULL,
  `harga` varchar(45) DEFAULT NULL,
  `status` enum('1','0','2') DEFAULT '0' COMMENT '2 kembali',
  `created_on` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`transaksi_id`, `user_id`, `produk_id`, `dari`, `sampai`, `jumlah`, `harga`, `status`, `created_on`) VALUES
(5, '7', '6', '2021-06-19', '2021-06-20', 0x31, '300000', '2', '2021-06-10 03:05:25'),
(6, '7', '6', '2021-06-12', '2021-06-13', 0x31, '300000', '2', '2021-06-10 03:06:35'),
(7, '8', '5', '2021-06-12', '2021-06-13', 0x31, '500000', '1', '2021-06-10 04:05:18'),
(8, '8', '5', '2021-06-12', '2021-06-13', 0x31, '500000', '1', '2021-06-10 04:05:18');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_jasa`
--

CREATE TABLE `transaksi_jasa` (
  `transaksi_jasa_id` int(11) NOT NULL,
  `user_id` varchar(45) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `jenis_jasa_id` varchar(45) DEFAULT NULL,
  `tanggal_mulai` date DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` enum('1','0') DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `password` varchar(60) DEFAULT NULL,
  `nama_lengkap` varchar(60) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `notelp` varchar(20) DEFAULT NULL,
  `level` enum('0','1') DEFAULT '1',
  `blokir` varchar(1) DEFAULT '0',
  `alamat` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`user_id`, `password`, `nama_lengkap`, `email`, `notelp`, `level`, `blokir`, `alamat`) VALUES
(6, '1234', 'test', 'ekop123@a.c', '08917934054', '1', '0', 'sdasdasd`'),
(7, 'admin', 'Administrator', 'admin@admin.com', '08917934054', '0', '0', 'sdasdasd`'),
(8, '1234567890', 'Muhammad Bagas Pangestu', 'bagas@user.com', '17721387210', '1', '0', 'Jalan Jalan dong');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `jenis_jasa`
--
ALTER TABLE `jenis_jasa`
  ADD PRIMARY KEY (`jenis_jasa_id`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`kategori_id`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`produk_id`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`transaksi_id`);

--
-- Indeks untuk tabel `transaksi_jasa`
--
ALTER TABLE `transaksi_jasa`
  ADD PRIMARY KEY (`transaksi_jasa_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `jenis_jasa`
--
ALTER TABLE `jenis_jasa`
  MODIFY `jenis_jasa_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `kategori_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `produk_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `transaksi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `transaksi_jasa`
--
ALTER TABLE `transaksi_jasa`
  MODIFY `transaksi_jasa_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
